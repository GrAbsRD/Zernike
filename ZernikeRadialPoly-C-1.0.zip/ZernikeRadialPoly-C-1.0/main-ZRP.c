#include <stdio.h>
#include <stdlib.h>


#include "ZernikeRadialPoly.h"



/* Compile via gcc : gcc ZernikeRadialPoly.c  main-ZRP.c -o RadiPoly -lm 
 * Compile via g++ : g++ ZernikeRadialPoly.c  main-ZRP.c -o RadiPoly
   Run: ./RadiPoly 12 0.231
   Run: ./RadiPoly 28 0.231
   Run: ./RadiPoly 29 0.231
   Note that for n = 28, r = 0.231:
        the SP2013 method is very slow for n = 28,
        the PR1989 method is very slow for n = 44, and
        the AbsRecur method is very slow for n = 60.  
     Speed/Efficiency: AbsIter  > AbsRecur > PR1989 > SP2013 
*/
int main(int argc, char* argv[])
{   
	
    int    n   = atoi(argv[1]);     
    double rho = atof(argv[2]);   // 0 <= r <= 1
    
	       
    const int num_method = 6;
    Procedure calc[num_method]; 
        
    calc[0].name = "CalcRadiPolyAbsIter,iterative"; 
    calc[0].f    = CalcRadiPolyAbsIter;
      
    calc[1].name = "CalcRadiPolyAbsRecu,recursive"; 
    calc[1].f    = CalcRadiPolyAbsRecu; 
    
    calc[2].name = "CalcRadiPolyPR1989, recursive"; 
    calc[2].f    = CalcRadiPolyPR1989;    
  
    calc[3].name = "CalcRadiPolyPR2022, recursive"; 
    calc[3].f    = CalcRadiPolyPR2022;
    
    calc[4].name = "CalcRadiPolySP2013, recursive";
    calc[4].f    = CalcRadiPolySP2013; 
    
    calc[5].name = "CalcRadiPolySP2022, recursive";
    calc[5].f    = CalcRadiPolySP2022; 
    

    
    /* Generate filenames for record the running time information */
    char* str4num = argv[1];
    char* prefix1 = "ProgRunTime-R";
    char* prefix2 = "RunTimeData-R";
    char* postfix = ".txt";
    int   len1 = CalcFilenameLength(prefix1, postfix, str4num);
    int   len2 = CalcFilenameLength(prefix2, postfix, str4num);
    char* filename = malloc((len1 + 1)*sizeof(char)); // for display
    char* dataname = malloc((len2 + 1)*sizeof(char)); // for data matrix
    GenFileName(filename, prefix1, postfix, str4num);
    GenFileName(dataname, prefix2, postfix, str4num);  
    

    FILE *fp = 0;
    fp = fopen(filename,"a");
    FILE *fpdata = 0;
    fpdata = fopen(dataname,"a");
    clock_t start, finish;
    int repeat_count = 10;
    printf("\nThe running time for different double indices (n, m):\n");
    for(int m = n; m >= 0; m = m-2){ // m = n, n-2, n-4, ..., 
        printf("n = %d, m = %d\n", n, m);
        fprintf(fp, "n = %d, m = %d\n", n, m);      // print to file 
        fprintf(fpdata, "%3d, %3d, %3d", n, m, n-m);  // print to data file
        for(int i = 0; i < num_method; i++){    
            start  = clock();
            // run the procedure for "repeat_count" times 
            for(int j = 0; j < repeat_count; j++){
                calc[i].Rnm = calc[i].f(n, m, rho);
            }
            finish = clock();     
            calc[i].time_cost = CalcProgRunTime(start, finish)/repeat_count; // average time cost

            printf("%s: R^%d_%d(%f) = %f,  time cost = %.9e (us), (average of %d times).\n", 
                    calc[i].name,
                    m,
                    n,
                    rho,
                    calc[i].Rnm,
                    calc[i].time_cost, 
                    repeat_count);
            fprintf(fp, "%s: R^%d_%d(%f) = %f,  time cost = %.9e (us), (average of %d times).\n", 
                    calc[i].name,
                    m,
                    n,
                    rho,
                    calc[i].Rnm,
                    calc[i].time_cost, 
                    repeat_count);
            fprintf(fpdata, ", %.9e", calc[i].time_cost);
        }
        printf("\n");
        fprintf(fp, "\n");
        fprintf(fpdata,"\n");
    }
    
    fclose(fp);
    fclose(fpdata);
    
    free(filename);
    free(dataname);
    
    return 0;
}


