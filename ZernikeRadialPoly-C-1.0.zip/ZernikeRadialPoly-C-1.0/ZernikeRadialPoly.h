#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <string.h>


typedef int Type;

typedef double (*Ptr2Fun)(unsigned int, int, double);

typedef struct{
    char*   name;
    Ptr2Fun f;
    double  Rnm;
    double  time_cost;
}Procedure;

double CalcProgRunTime(clock_t start, clock_t finish);
Type   Abs(Type m);
void   CheckInput(unsigned int n, int m, double r);
int    CvtNM2K(unsigned int n, int m);
double CalcPower(double x, int n);
double CalcLeafNodeTypeA(double r, int m);
double CalcLeafNodeTypeB(double r, int m);

double CalcRadiPolyAbsRecu(unsigned int n, int m, double r);
double CalcRadiPolyAbsIter(unsigned int n, int m, double r);

double CalcRadiPolyPR1989(unsigned int n, int m, double r);
double CalcRadiPolyPR2022(unsigned int n, int m, double r);

double CalcRadiPolySP2013(unsigned int n, int m, double r);
double CalcRadiPolySP2022(unsigned int n, int m, double r);


int    CalcFilenameLength(char* prefix, char* postfix, char* str4num);
void   GenFileName(char* filename, char* prefix, char* postfix, char* str4num);
