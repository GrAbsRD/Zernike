#include "ZernikeRadialPoly.h"

int CalcFilenameLength(char* prefix, char* postfix, char* str4num)
{
	return strlen(prefix) + strlen(postfix) + strlen(str4num);
}

void GenFileName(char* filename, char* prefix, char* postfix, char* str4num)
{
	strcat(filename,prefix);
	strcat(filename,str4num);
	strcat(filename,postfix);

}


double CalcProgRunTime(clock_t start, clock_t finish)
{
   double d =  finish - start; // unit: micro second, us
   //double d =  (finish - start)/CLOCKS_PER_SEC;  // unit: second, s
   return d;
}

Type Abs(Type m){ 
	return (m < 0) ? (-m):m; 
}

void CheckInput(unsigned int n, int m, double r)
{
    if(Abs(m)> n || (n-m) & 1 || r > 1 || r < 0){
        printf("Input error!\n");
        exit(0);
    }
}


int  CvtNM2K(unsigned int n, int m)
{
	int k = (n- Abs(m))/2;	 
	return k;
}


double CalcPower(double x, int n)
{
    double prod = 1;
    while( n >= 1){
        if(n & 1) prod *= x;
        x *= x;
        n >>= 1;
    }
    return prod;
}

double CalcLeafNodeTypeA(double r, int m)
{
	return CalcPower(r, m);
}

double CalcLeafNodeTypeB(double r, int m)
{
	return CalcPower(r, m)*((m+2)*r*r - (m+1));
}

/* New formula by Hong-Yan Zhang */ 
double CalcRadiPolyAbsRecu(unsigned int n, int m, double r)
{  
    m = Abs(m); // R^m_n = R^{-m}_n
    int p = n-m;
    double A = CalcLeafNodeTypeA(r, m); // pow(r, m);    // R^m_m(r)
    double B = CalcLeafNodeTypeB(r, m); // R^m_{m+2}(r)
    if( p == 0) {return A;}
    if( p == 2) {return B;}
    return (2*n*r*CalcRadiPolyAbsRecu(n-1,m+1,r)-(n+m)*CalcRadiPolyAbsRecu(n-2,m,r))/p;
}



double CalcRadiPolyAbsIter(unsigned int n, int m, double r)
{
	m = Abs(m);
	
	int p = n-m;
	if( p == 0) return CalcLeafNodeTypeA(r, m);
	if( p == 2) return CalcLeafNodeTypeB(r, m);
	
	int k = p/2; // or: k = CvtNM2K(n,m); 
	double* value = (double*) malloc(sizeof(double)*k);
	for(int i = 0; i < k; i++){
		value[i] = CalcLeafNodeTypeB(r, m+k-1-i); 
	}
	
	int n_start, n_pos;
	int m_start, m_pos;
	double F1, F2;

	for(int level = k-1; level >= 1; level--){
		n_start = n - (level-1);
		m_start = m + (level-1);
 		for(int i = 0; i < level; i++)
 		{
			m_pos = m_start -i;
			n_pos = n_start -i;
			F1 = 2.0*n_pos/(n_pos - m_pos);
			F2 = 1.0 - F1;
			value[i] = r*F1*value[i] + F2*value[i+1];
		}
	}

	double R = value[0];
	
	free(value);

	return R;
}


/* SP2013: Shakibaei-Paramesran 2013, paper, see eq.(18) */
double CalcRadiPolySP2013(unsigned int n, int m, double r)
{
    m = Abs(m); // R^m_n = R^{-m}_n
    if(n < m)  return 0; // Attention, please! 
    if(n == 0) return 1; // leaf node A
    if(n == 1) return r; // leaf node B
    return r*(CalcRadiPolySP2013(n-1, Abs(m-1),r) + CalcRadiPolySP2013(n-1,m+1, r)) 
            -CalcRadiPolySP2013(n-2, m, r);
}

/* SP2022: Shakibaei-Paramesran-Abs 2022, paper, see eq.(18) */
double CalcRadiPolySP2022(unsigned int n, int m, double r)
{
    m = Abs(m); // R^m_n = R^{-m}_n
    int p =  n-m;
    double A = CalcLeafNodeTypeA(r, m); // pow(r, m);    // R^m_m(r)
    double B = CalcLeafNodeTypeB(r, m); // R^m_{m+2}(r)
    if( p == 0) {return A;}
    if( p == 2) {return B;}
    return r*(CalcRadiPolySP2022(n-1, Abs(m-1),r) + CalcRadiPolySP2022(n-1,m+1, r)) 
            -CalcRadiPolySP2022(n-2, m, r);
}


/* PR1989: Prata-Rusch 1989, paper, see eq.(9) in SP2013 */
double CalcRadiPolyPR1989(unsigned int n, int m, double r)
{
    m = Abs(m); // R^m_n = R^{-m}_n

    if(n == 0) return 1; // leaf node A
    if(n == 1) return r; // leaf node B

    double L1 =(2.0*n)/(n+m);
    double L2 = 1.0 - L1;
    return r*L1*CalcRadiPolyPR1989(n-1, Abs(m-1), r) + L2*CalcRadiPolyPR1989(n-2, m, r);
}

/* PR1989: Prata-Rusch-Abs 1989-2022, */
double CalcRadiPolyPR2022(unsigned int n, int m, double r)
{
    m = Abs(m); // R^m_n = R^{-m}_n
    int p =  n-m;
    double A = CalcLeafNodeTypeA(r, m); // R^m_m(r)
    double B = CalcLeafNodeTypeB(r, m); // R^m_{m+2}(r)
    if( p == 0) {return A;}
    if( p == 2) {return B;}
    double L1 =(2.0*n)/(n+m);
    double L2 = 1.0 - L1;
    return r*L1*CalcRadiPolyPR2022(n-1, Abs(m-1), r) + L2*CalcRadiPolyPR2022(n-2, m, r);
}





